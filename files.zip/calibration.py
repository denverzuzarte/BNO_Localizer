"""
auv_eskf/calibration.py — Pre-mission IMU calibration.

Usage:
    from auv_eskf.calibration import calibrate_imu
    b0, std_acc = calibrate_imu(accel_samples_ms2, quat_samples_wxyz)
    # Paste b0 and std_acc into ESKFConfig.
"""
import numpy as np
from typing import Tuple


def calibrate_imu(accel_samples: np.ndarray,
                  quat_samples:  np.ndarray,
                  g: float = 9.81) -> Tuple[np.ndarray, float]:
    """
    Estimate accelerometer bias (b0) and noise (std_acc) from a
    static recording taken before the mission.

    Parameters
    ----------
    accel_samples : (N, 3)  raw specific force in body frame [m/s²]
                    If your IMU outputs in g, multiply by 9.81 first.
    quat_samples  : (N, 4)  orientation quaternion [w, x, y, z]
    g             : gravitational acceleration [m/s²]

    Returns
    -------
    b0      : (2,)  NED XY bias [m/s²]   → paste into ESKFConfig.b0
    std_acc : float NED XY noise std      → paste into ESKFConfig.std_acc

    Requirements
    ------------
    - Vehicle completely stationary during recording
    - At least 60 seconds of data
    - Recorded at operating temperature (bias is temperature-dependent)
    """
    N = len(accel_samples)
    if N < 100:
        raise ValueError(f"Need ≥100 samples, got {N}.")

    g_ned = np.array([0.0, 0.0, g])
    a_ned = np.zeros((N, 3))
    for i in range(N):
        q = np.asarray(quat_samples[i], dtype=float)
        q /= np.linalg.norm(q)
        w, x, y, z = q
        R = np.array([
            [1-2*(y*y+z*z), 2*(x*y-z*w),   2*(x*z+y*w)  ],
            [2*(x*y+z*w),   1-2*(x*x+z*z), 2*(y*z-x*w)  ],
            [2*(x*z-y*w),   2*(y*z+x*w),   1-2*(x*x+y*y)]
        ])
        a_ned[i] = R @ np.asarray(accel_samples[i], dtype=float) + g_ned

    b0      = a_ned[:, :2].mean(axis=0)
    std_acc = float(a_ned[:, :2].std())

    print("─── IMU Calibration Result ───────────────────────────────")
    print(f"  Samples     : {N}  ({N/50:.0f} s at ~50 Hz)")
    print(f"  b0  [N, E]  : [{b0[0]:+.5f}, {b0[1]:+.5f}]  m/s²")
    print(f"  std_acc     : {std_acc:.5f}  m/s²")
    print(f"  Down bias   : {a_ned[:,2].mean():+.5f}  m/s²  (unused by filter)")
    print("──────────────────────────────────────────────────────────")
    print("  Paste into ESKFConfig:")
    print(f"    b0      = [{b0[0]:+.5f}, {b0[1]:+.5f}]")
    print(f"    std_acc = {std_acc:.5f}")
    print("──────────────────────────────────────────────────────────")
    return b0, std_acc
