"""
auv_eskf — Error-State Kalman Filter for AUV navigation.
"""
from auv_eskf.eskf import ESKF, ESKFConfig, is_outlier
__all__ = ["ESKF", "ESKFConfig", "is_outlier"]
__version__ = "1.0.0"
