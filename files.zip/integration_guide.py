"""
auv_eskf/integration_guide.py
==============================
Copy-paste examples.  READ this file; do not import it.
"""

# ── STEP 1: PRE-MISSION CALIBRATION ──────────────────────────────────────────

CALIBRATION = """
import numpy as np
from auv_eskf.calibration import calibrate_imu

# Collect ~60 s of data with AUV completely stationary at operating temperature.
# accel_samples : (N, 3) raw IMU accel in m/s²  (multiply g-output by 9.81)
# quat_samples  : (N, 4) quaternion [w, x, y, z]

b0, std_acc = calibrate_imu(accel_samples, quat_samples)
# Printed output tells you exactly what to paste into ESKFConfig.
"""

# ── STEP 2: CONFIGURE ────────────────────────────────────────────────────────

CONFIGURATION = """
from auv_eskf import ESKF, ESKFConfig

cfg = ESKFConfig(
    # ── IMU ────────────────────────────────────────────────────────────
    imu_rate_hz   = 10.0,    # Hz  ← match your IMU rate

    # ── Process noise  (from calibration) ──────────────────────────────
    std_acc       = 0.127,   # m/s²     ← replace with calibration result
    std_bias_rw   = 1e-4,    # m/s²/√s  ← tune if needed
    T_bias        = 300.0,   # s         ← increase for missions > 30 min

    # ── Position sensor ────────────────────────────────────────────────
    std_pos       = 0.30,    # m         ← from sensor spec

    # ── Initial conditions ─────────────────────────────────────────────
    b0            = [-0.479, -0.017],  # m/s²  ← from calibration
    P0_pos        = 0.10,   # m²        ← starting position uncertainty²
    P0_vel        = 0.50,   # m²/s²
    P0_bias       = 0.05,   # m²/s⁴    ← 0.05 if calibrated, 0.5 if not
)
"""

# ── STEP 3A: ROS 2 ───────────────────────────────────────────────────────────

ROS2 = """
import numpy as np
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
from geometry_msgs.msg import PoseWithCovarianceStamped, PoseStamped
from auv_eskf import ESKF, ESKFConfig, is_outlier

class ESKFNode(Node):
    def __init__(self):
        super().__init__('auv_eskf')

        cfg = ESKFConfig(
            imu_rate_hz = 10.0,
            std_acc     = 0.127,
            std_pos     = 0.30,
            b0          = [-0.479, -0.017],
            P0_bias     = 0.05,
        )
        # Initialise without a starting position.
        # Call eskf.reset_position() once first fix arrives.
        self.eskf = ESKF(cfg)
        self._prev_fix = None
        self._jump_gate = 1.5   # m  ← max_speed × sensor_dt × 3

        self.create_subscription(Imu, '/imu/data', self._imu_cb, 10)
        self.create_subscription(
            PoseWithCovarianceStamped,
            '/vision/pose', self._vision_cb, 10)
        self._pub = self.create_publisher(PoseStamped, '/eskf/pose', 10)

    def _imu_cb(self, msg: Imu):
        # ROS IMU: accel already in m/s², quaternion is [x, y, z, w] → reorder
        accel = np.array([msg.linear_acceleration.x,
                          msg.linear_acceleration.y,
                          msg.linear_acceleration.z])
        quat  = np.array([msg.orientation.w,   # reorder to [w, x, y, z]
                          msg.orientation.x,
                          msg.orientation.y,
                          msg.orientation.z])
        self.eskf.predict(accel, quat)

        out = PoseStamped()
        out.header.stamp    = msg.header.stamp
        out.header.frame_id = 'ned'
        out.pose.position.x = float(self.eskf.position[0])
        out.pose.position.y = float(self.eskf.position[1])
        self._pub.publish(out)

    def _vision_cb(self, msg: PoseWithCovarianceStamped):
        fix = np.array([msg.pose.pose.position.x,
                        msg.pose.pose.position.y])

        if is_outlier(fix, self._prev_fix, self._jump_gate):
            self.get_logger().warn('Vision fix rejected (jump gate)')
            return

        if self._prev_fix is None:
            self.eskf.reset_position(fix)

        self.eskf.update(fix)
        self._prev_fix = fix

def main():
    rclpy.init()
    rclpy.spin(ESKFNode())
"""

# ── STEP 3B: BARE-METAL / EMBEDDED ───────────────────────────────────────────

BARE_METAL = """
from auv_eskf import ESKF, ESKFConfig, is_outlier
import numpy as np

cfg = ESKFConfig(
    imu_rate_hz = 10.0,
    std_acc     = 0.127,
    std_pos     = 0.30,
    b0          = [-0.479, -0.017],
    P0_bias     = 0.05,
)

# Get first fix to initialise position
first_fix = your_sensor.read_position()
eskf = ESKF(cfg, p0=first_fix)
prev_fix = first_fix
jump_gate = 1.5   # m  ← adjust to your vehicle speed and sensor rate

while mission_running():

    # IMU tick  ─────────────────────────────────────────────────────────
    accel = imu.read_accel_ms2()     # [ax, ay, az]  m/s²  (raw, not gravity-free)
    quat  = imu.read_quaternion()    # [w, x, y, z]
    eskf.predict(accel, quat)

    # Position fix tick  ────────────────────────────────────────────────
    if sensor.has_new_fix():
        fix = sensor.read_position_ned()  # [north, east]  m
        if not is_outlier(fix, prev_fix, jump_gate):
            eskf.update(fix)
            prev_fix = fix

    # Read outputs  ─────────────────────────────────────────────────────
    pos  = eskf.position       # [north, east]  m
    vel  = eskf.velocity       # [vn, ve]        m/s
    std  = eskf.position_std   # [σn, σe]        m
    bias = eskf.accel_bias     # [bn, be]        m/s²

    nav.set_position(pos)
    logger.write(eskf.state)
"""

# ── FRAME CONVENTION ─────────────────────────────────────────────────────────

FRAMES = """
The filter outputs in NED (North-East-Down):
  position[0] = North   (+ve forward if AUV starts heading North)
  position[1] = East    (+ve to the right)

Quaternion [w, x, y, z] must represent body → NED rotation.
  ROS IMU topics use [x, y, z, w] → reorder to [w, x, y, z].
  Most IMU drivers let you configure the output frame — set to NED.
  If your IMU outputs body→ENU, apply ENU→NED rotation first.

Accelerometer:
  Pass the RAW reading in m/s² — gravity is removed inside predict().
  If your driver outputs in g-units: multiply by 9.81 before passing.
  Do NOT pre-subtract gravity yourself.
"""

# ── TUNING CHECKLIST ─────────────────────────────────────────────────────────

TUNING = """
Before first water trial:
  [ ] Run calibrate_imu() with 60 s static recording
  [ ] Set b0 and std_acc from calibration output
  [ ] Set std_pos to match your sensor spec
  [ ] Set imu_rate_hz to your actual IMU rate
  [ ] Set jump_gate ≈ max_speed × sensor_dt × 3

After first water trial, check logs:
  [ ] eskf.accel_bias converges within ~10 s of receiving fixes
      Oscillates → decrease std_bias_rw
      Drifts throughout run → decrease T_bias
  [ ] eskf.position_std stays small when sensor is running
      Grows between fixes → increase std_acc
  [ ] Few fixes rejected (< 5% of stream)
      Many rejected → increase jump_gate
      None rejected, trajectory noisy → decrease jump_gate

Long-endurance missions (> 30 min):
  [ ] Increase T_bias to 500–1000 s
  [ ] If vehicle stops mid-mission, optionally update b0:
        eskf._b = new_calibration_b0  (resets bias estimate)
"""
