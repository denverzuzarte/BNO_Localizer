"""
auv_eskf/eskf.py  — Error-State Kalman Filter for AUV 2-D navigation.

Based on:
    Fossen, T.I. (2023). Control Engineering Practice 138, 105603.

State vector (6 states):
    x = [px, py,  vx, vy,  bx, by]
         position  velocity  accel-bias   (NED North-East)

Quick start:
    from auv_eskf.eskf import ESKF, ESKFConfig
    cfg  = ESKFConfig(...)
    eskf = ESKF(cfg, p0=[x0, y0])
    eskf.predict(accel_ms2_xyz, quat_wxyz)   # every IMU tick
    eskf.update(pos_ned_xy)                   # every position fix
    pos = eskf.position                       # [north, east] m
"""

import numpy as np
from dataclasses import dataclass, field
from typing import Optional


# ─────────────────────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ESKFConfig:
    """
    All tunable parameters.  Edit before deploying.

    HOW TO SET EACH PARAMETER
    ─────────────────────────
    imu_rate_hz
        Your IMU publication rate in Hz.

    std_acc  [m/s²]
        1-sigma white noise of gravity-removed horizontal acceleration.
        MEASURE: 60 s of stationary IMU → std of NED XY accel after
        removing the mean.  Typical MEMS: 0.05–0.30 m/s².

    std_bias_rw  [m/s²/√s]
        Rate at which accelerometer bias drifts.
        START: 1e-4.  If bias estimate is noisy → decrease.
        If filter diverges over long runs → increase.
        Range: 1e-5 to 1e-3.

    T_bias  [s]
        Bias model time constant.
        Short missions (< 5 min)  → 100–300 s
        Long endurance (> 30 min) → 500–1000 s
        Rapidly changing temperature → 50–100 s

    std_pos  [m]
        1-sigma accuracy of the position sensor.
        Vision localisation : 0.10–0.50 m
        USBL short range    : 0.50–2.0  m
        LBL well-calibrated : 0.10–0.50 m

    b0  [m/s²]
        Initial bias estimate.
        MEASURE: 60 s stationary calibration → mean of NED XY accel
        after gravity removal.  Use [0.0, 0.0] if not calibrated.

    P0_pos   [m²]       Initial position uncertainty squared.
    P0_vel   [m²/s²]    Initial velocity uncertainty squared.
    P0_bias  [m²/s⁴]    0.05 if b0 calibrated, 0.5 if not.

    JUMP GATE
        Outlier rejection is handled by the CALLER before update().
        Use the helper  is_outlier(new_fix, prev_fix, jump_gate)
        or implement your own check.  See integration_guide.py.
    """

    imu_rate_hz:   float = 10.0
    std_acc:       float = 0.127     # m/s²        ← from static calibration
    std_bias_rw:   float = 1e-4      # m/s²/√s     ← tune empirically
    T_bias:        float = 300.0     # s            ← tune to mission length
    std_pos:       float = 0.30      # m            ← from sensor spec
    b0:            list  = field(default_factory=lambda: [0.0, 0.0])
    P0_pos:        float = 0.10      # m²
    P0_vel:        float = 0.50      # m²/s²
    P0_bias:       float = 0.50      # m²/s⁴  (0.05 if b0 calibrated)


# ─────────────────────────────────────────────────────────────────────────────
# Outlier rejection helper  (call this BEFORE eskf.update)
# ─────────────────────────────────────────────────────────────────────────────

def is_outlier(new_fix:   np.ndarray,
               prev_fix:  Optional[np.ndarray],
               threshold: float) -> bool:
    """
    Return True if new_fix should be rejected as an outlier.

    Checks whether the raw consecutive sensor step exceeds threshold.
    Call this BEFORE eskf.update().  If it returns True, discard the fix.

    Parameters
    ----------
    new_fix   : [px, py] latest fix from the sensor
    prev_fix  : [px, py] previous fix that was used  (None on first call)
    threshold : jump_gate value [m]  — typically max_speed × sensor_dt × 3

    Example
    -------
        prev = None
        for fix in vision_stream:
            if not is_outlier(fix, prev, threshold=1.5):
                eskf.update(fix)
                prev = fix
    """
    if prev_fix is None:
        return False
    return float(np.linalg.norm(
        np.asarray(new_fix) - np.asarray(prev_fix)
    )) > threshold


# ─────────────────────────────────────────────────────────────────────────────
# Main filter class
# ─────────────────────────────────────────────────────────────────────────────

class ESKF:
    """
    6-state feedback Error-State Kalman Filter for AUV 2-D navigation.

    Coordinate convention
    ─────────────────────
    NED (North-East-Down):
      position[0] = North,  position[1] = East
    Quaternion format: [w, x, y, z]  (scalar first — as output by most IMU drivers)

    Typical loop:
        eskf.predict(accel_ms2, quat)        # every IMU tick
        if new_vision_fix and not outlier:
            eskf.update(pos_ned_xy)          # every clean fix
    """

    _N = 6

    def __init__(self,
                 cfg: ESKFConfig,
                 p0:  Optional[list] = None):
        self._cfg = cfg
        self._h   = 1.0 / cfg.imu_rate_hz
        self._g   = np.array([0.0, 0.0, 9.81])

        self._p = np.asarray(p0, dtype=float).copy() if p0 is not None else np.zeros(2)
        self._v = np.zeros(2)
        self._b = np.asarray(cfg.b0, dtype=float).copy()

        self._P = np.diag([
            cfg.P0_pos,  cfg.P0_pos,
            cfg.P0_vel,  cfg.P0_vel,
            cfg.P0_bias, cfg.P0_bias,
        ])
        self._R = cfg.std_pos ** 2 * np.eye(2)

        self.n_updates:  int = 0
        self.last_innovation: Optional[np.ndarray] = None

    # ── Prediction step  (call at every IMU tick) ─────────────────────

    def predict(self,
                accel_body: np.ndarray,
                quat_wxyz:  np.ndarray) -> None:
        """
        IMU propagation.  Call at imu_rate_hz.

        Parameters
        ----------
        accel_body : [ax, ay, az] raw specific force in body frame [m/s²]
                     RAW reading — do NOT pre-subtract gravity.
                     If your IMU outputs in g, multiply by 9.81 first.
        quat_wxyz  : [w, x, y, z] orientation quaternion (body→NED).
                     Will be normalised internally.
        """
        q  = np.asarray(quat_wxyz, dtype=float)
        q /= np.linalg.norm(q)
        w, x, y, z = q
        R = np.array([
            [1-2*(y*y+z*z), 2*(x*y-z*w),   2*(x*z+y*w)  ],
            [2*(x*y+z*w),   1-2*(x*x+z*z), 2*(y*z-x*w)  ],
            [2*(x*z-y*w),   2*(y*z+x*w),   1-2*(x*x+y*y)]
        ])

        a_xy = (R @ np.asarray(accel_body, dtype=float) + self._g)[:2]
        fc   = a_xy - self._b
        h    = self._h

        self._p = self._p + h*self._v + 0.5*h*h*fc
        self._v = self._v + h*fc

        A = np.zeros((6, 6))
        A[0:2, 2:4] =  np.eye(2)
        A[2:4, 4:6] = -np.eye(2)
        A[4:6, 4:6] = -(1.0/self._cfg.T_bias) * np.eye(2)
        Ad = np.eye(6) + h*A + 0.5*h*h*(A@A)

        Qd = np.zeros((6, 6))
        Qd[2:4, 2:4] = self._cfg.std_acc**2     * h * np.eye(2)
        Qd[4:6, 4:6] = self._cfg.std_bias_rw**2 * h * np.eye(2)

        self._P = Ad @ self._P @ Ad.T + Qd

    # ── Measurement update  (call whenever a clean fix arrives) ───────

    def update(self, pos_fix: np.ndarray) -> None:
        """
        Position fix update.

        Call this only with CLEAN fixes (after outlier rejection).
        Use is_outlier() in this module to pre-screen raw sensor output.

        Parameters
        ----------
        pos_fix : [px, py] measured NED position [m].
                  Must be in the same frame as p0.
        """
        pm  = np.asarray(pos_fix, dtype=float)
        inn = pm - self._p
        self.last_innovation = inn.copy()

        C   = np.zeros((2, 6)); C[0:2, 0:2] = np.eye(2)
        S   = C @ self._P @ C.T + self._R
        K   = self._P @ C.T @ np.linalg.solve(S.T, np.eye(2)).T
        dx  = K @ inn
        IKC = np.eye(6) - K @ C
        self._P = IKC @ self._P @ IKC.T + K @ self._R @ K.T
        self._P = 0.5 * (self._P + self._P.T)

        self._p += dx[0:2]
        self._v += dx[2:4]
        self._b += dx[4:6]
        self.n_updates += 1

    def reset_position(self, p0: np.ndarray) -> None:
        """Reinitialise position (e.g. after a relocalization event)."""
        self._p = np.asarray(p0, dtype=float).copy()

    # ── Outputs ───────────────────────────────────────────────────────

    @property
    def position(self) -> np.ndarray:
        """[north, east] m."""
        return self._p.copy()

    @property
    def velocity(self) -> np.ndarray:
        """[vn, ve] m/s."""
        return self._v.copy()

    @property
    def accel_bias(self) -> np.ndarray:
        """[bn, be] m/s²."""
        return self._b.copy()

    @property
    def position_std(self) -> np.ndarray:
        """1-sigma position uncertainty [σn, σe] m."""
        return np.sqrt(np.diag(self._P[0:2, 0:2]))

    @property
    def covariance(self) -> np.ndarray:
        """Full 6×6 error covariance matrix."""
        return self._P.copy()

    @property
    def state(self) -> dict:
        """All outputs as a dict — convenient for logging."""
        return {
            'position':     self.position,
            'velocity':     self.velocity,
            'accel_bias':   self.accel_bias,
            'position_std': self.position_std,
            'n_updates':    self.n_updates,
        }
