"""
auv_eskf/validate.py — Validate the filter against recorded data.

Usage:
    python -m auv_eskf.validate \\
        --imu  /path/_imu_data.csv \\
        --pose /path/_localization_pose.csv \\
        --duration 400
"""
import csv, argparse, sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from auv_eskf import ESKF, ESKFConfig


def validate(imu_path, pose_path, duration_s, cfg=None, save_plot=True):
    if cfg is None:
        cfg = ESKFConfig()

    imu_rows  = list(csv.DictReader(open(imu_path)))
    pose_rows = list(csv.DictReader(open(pose_path)))
    N_imu     = len(imu_rows)
    N_pose    = len(pose_rows)
    t_imu     = np.linspace(0, duration_s, N_imu)
    t_pose    = np.linspace(0, duration_s, N_pose)
    h         = float(t_imu[1] - t_imu[0])

    acl  = np.array([[float(r['acl_x']),float(r['acl_y']),float(r['acl_z'])]
                      for r in imu_rows]) * 9.81
    quat = np.array([[float(r['orient_w']),float(r['orient_x']),
                      float(r['orient_y']),float(r['orient_z'])]
                     for r in imu_rows])
    quat /= np.linalg.norm(quat, axis=1, keepdims=True)
    vis_x = np.array([float(r['pos_x']) for r in pose_rows])
    vis_y = np.array([float(r['pos_y']) for r in pose_rows])

    # For each IMU step, find nearest pose sample
    pose_idx = np.searchsorted(t_pose, t_imu).clip(1, N_pose - 1)
    # Consecutive step distances between adjacent pose samples
    dists = np.sqrt(np.diff(vis_x)**2 + np.diff(vis_y)**2)

    print(f"\nValidation")
    print(f"  IMU  : {N_imu}pts @ {1/h:.1f}Hz")
    print(f"  Pose : {N_pose}pts @ {1/(t_pose[1]-t_pose[0]):.1f}Hz")
    print(f"  std_pos={cfg.std_pos}m  std_acc={cfg.std_acc}m/s²")
    print(f"  b0={cfg.b0}  jump_gate={cfg.std_pos*5:.2f}m")

    # jump_gate used to drop vision dropout frames
    jump_gate = cfg.std_pos * 5.0   # conservative: 5× sensor noise

    eskf = ESKF(cfg, p0=[vis_x[0], vis_y[0]])
    p_est   = np.zeros((N_imu, 2)); p_est[0]   = eskf.position
    b_est   = np.zeros((N_imu, 2)); b_est[0]   = eskf.accel_bias
    std_est = np.zeros((N_imu, 2))

    for k in range(N_imu - 1):
        eskf.predict(acl[k], quat[k])
        pi  = pose_idx[k]
        fix = np.array([vis_x[pi], vis_y[pi]])
        # Accept fix if the consecutive POSE step is within jump_gate
        # (this rejects vision dropout frames where position jumps suddenly)
        if dists[pi - 1] < jump_gate:
            eskf.update(fix)
        p_est[k+1]   = eskf.position
        b_est[k+1]   = eskf.accel_bias
        std_est[k+1] = eskf.position_std

    # Build clean reference (same gate, for evaluation)
    ref_x = np.full(N_imu, np.nan); ref_y = np.full(N_imu, np.nan)
    for k in range(N_imu):
        pi = pose_idx[k]
        if dists[pi - 1] < jump_gate:
            ref_x[k] = vis_x[pi]; ref_y[k] = vis_y[pi]
    valid = ~np.isnan(ref_x)

    err   = np.linalg.norm(
        p_est[valid] - np.column_stack([ref_x[valid], ref_y[valid]]),
        axis=1)
    rmse  = float(np.sqrt(np.mean(err**2)))
    maxe  = float(err.max())
    final = float(np.linalg.norm(
        p_est[-1] - np.array([ref_x[valid][-1], ref_y[valid][-1]])))

    print(f"\n  ┌────────────────────────────────────┐")
    print(f"  │  RMSE        : {rmse:>8.3f} m           │")
    print(f"  │  Max error   : {maxe:>8.3f} m           │")
    print(f"  │  Final error : {final:>8.3f} m           │")
    print(f"  │  Fix updates : {eskf.n_updates:>8d}               │")
    print(f"  └────────────────────────────────────┘")
    print(f"  Vision floor ≈ {cfg.std_pos:.2f} m")
    print(f"  Final bias: [{b_est[-1,0]:+.4f}, {b_est[-1,1]:+.4f}] m/s²")

    if rmse > 5 * cfg.std_pos:
        print(f"\n  ⚠  RMSE is {rmse/cfg.std_pos:.1f}× sensor floor. Check b0 and std_pos.")
    elif rmse < 3 * cfg.std_pos:
        print(f"\n  ✓  RMSE within 3× sensor floor — filter is near-optimal.")

    if save_plot:
        try:
            import matplotlib; matplotlib.use("Agg")
            import matplotlib.pyplot as plt
            fig, axes = plt.subplots(1, 3, figsize=(15, 5))
            fig.suptitle(f"ESKF Validation — RMSE={rmse:.2f}m  (floor≈{cfg.std_pos}m)",
                         fontsize=11)
            axes[0].plot(vis_y, vis_x, 'k-', lw=0.5, alpha=0.3, label='Vision ref')
            axes[0].plot(p_est[:,1], p_est[:,0], 'tab:blue', lw=1.0, label='ESKF')
            axes[0].set_xlabel("East [m]"); axes[0].set_ylabel("North [m]")
            axes[0].set_title("Trajectory"); axes[0].legend(fontsize=8)
            axes[0].grid(True, alpha=0.3)
            try: axes[0].set_aspect('equal')
            except: pass
            ea = np.full(N_imu, np.nan)
            for k in range(N_imu):
                if valid[k]:
                    ea[k] = np.linalg.norm(p_est[k]-np.array([ref_x[k],ref_y[k]]))
            axes[1].plot(t_imu, ea, 'tab:blue', lw=0.8)
            axes[1].fill_between(t_imu, 0,
                                  np.where(valid, std_est[:,0], np.nan),
                                  color='tab:blue', alpha=0.15)
            axes[1].axhline(cfg.std_pos, color='k', ls='--', lw=1.2,
                             label=f'{cfg.std_pos}m floor')
            axes[1].set_xlabel("Time [s]"); axes[1].set_ylabel("Error [m]")
            axes[1].set_title("Position error over time")
            axes[1].legend(fontsize=8); axes[1].grid(True, alpha=0.3)
            axes[2].plot(t_imu, b_est[:,0], label='Bias N', lw=1.0)
            axes[2].plot(t_imu, b_est[:,1], label='Bias E', lw=1.0)
            axes[2].set_xlabel("Time [s]"); axes[2].set_ylabel("[m/s²]")
            axes[2].set_title("Bias convergence")
            axes[2].legend(fontsize=8); axes[2].grid(True, alpha=0.3)
            plt.tight_layout()
            plt.savefig("validation_result.png", dpi=150); plt.close()
            print("  Plot → validation_result.png")
        except ImportError:
            pass
    return rmse, maxe, final


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--imu",      required=True)
    p.add_argument("--pose",     required=True)
    p.add_argument("--duration", type=float, default=400.0)
    p.add_argument("--std-pos",  type=float, default=0.30)
    p.add_argument("--std-acc",  type=float, default=0.127)
    p.add_argument("--b0-n",     type=float, default=-0.479)
    p.add_argument("--b0-e",     type=float, default=-0.017)
    a = p.parse_args()
    cfg = ESKFConfig(imu_rate_hz=10.0, std_acc=a.std_acc, std_pos=a.std_pos,
                     b0=[a.b0_n, a.b0_e], P0_bias=0.05)
    validate(a.imu, a.pose, a.duration, cfg)
