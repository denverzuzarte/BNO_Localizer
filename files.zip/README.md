# auv_eskf

Error-State Kalman Filter for AUV 2-D inertial navigation.
Fuses IMU (accelerometer + orientation quaternion) with a position sensor
(vision localisation, acoustic USBL/LBL, or any NED position fix).

**Dependency:** `numpy` only.

---

## Files

| File | Purpose |
|---|---|
| `eskf.py` | Core filter — the only file needed at runtime |
| `calibration.py` | Pre-mission bias + noise estimation from static recording |
| `validate.py` | Run filter against your recorded data before deployment |
| `integration_guide.py` | ROS 2 and bare-metal code examples (read, don't import) |

---

## Quick start

```python
from auv_eskf import ESKF, ESKFConfig, is_outlier

cfg = ESKFConfig(
    imu_rate_hz = 10.0,
    std_acc     = 0.127,      # from calibration
    std_pos     = 0.30,       # from sensor spec
    b0          = [-0.479, -0.017],  # from calibration
    P0_bias     = 0.05,
)

eskf     = ESKF(cfg, p0=[start_north, start_east])
prev_fix = None
JUMP_GATE = 1.5   # m — set to max_speed × sensor_dt × 3

# --- IMU callback (call at imu_rate_hz) ---
eskf.predict(accel_ms2_xyz, quat_wxyz)

# --- Position fix callback ---
if not is_outlier(new_fix, prev_fix, JUMP_GATE):
    eskf.update(new_fix)
    prev_fix = new_fix

# --- Read outputs ---
pos  = eskf.position      # [north, east]  m
vel  = eskf.velocity      # [vn, ve]        m/s
std  = eskf.position_std  # [σn, σe]        m  (1-sigma)
```

---

## Pre-mission calibration

```python
from auv_eskf.calibration import calibrate_imu
b0, std_acc = calibrate_imu(accel_Nx3_ms2, quat_Nx4_wxyz)
# Printed output tells you exactly what to paste into ESKFConfig.
```

---

## Validate before first water trial

```bash
python -m auv_eskf.validate \
    --imu  /path/_imu_data.csv \
    --pose /path/_localization_pose.csv \
    --duration 400
```

---

## Parameter reference

| Parameter | How to set | Default |
|---|---|---|
| `imu_rate_hz` | Match your IMU rate | 10.0 Hz |
| `std_acc` | Static calibration | 0.127 m/s² |
| `b0` | Static calibration | [0.0, 0.0] |
| `std_pos` | Sensor spec | 0.30 m |
| `std_bias_rw` | Tune: oscillates→↓, drifts→↑ | 1e-4 |
| `T_bias` | Short mission: 100–300 s / Long: 500–1000 s | 300 s |
| `P0_bias` | 0.05 if b0 calibrated, 0.5 if not | 0.50 |
| `JUMP_GATE` | `max_speed × sensor_dt × 3` (passed to `is_outlier()`) | — |

Full tuning procedure in `integration_guide.py`.

---

## Frame convention

- Outputs in **NED**: `position[0]` = North, `position[1]` = East
- Quaternion format: **[w, x, y, z]** (ROS uses [x,y,z,w] → reorder)
- Pass **raw** accelerometer in **m/s²** — gravity removed internally
